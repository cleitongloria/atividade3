/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.cleiton.introducao_junit5;

/**
 *
 * @author cleit
 */
public class MathUtil {

    public static int mdc(int a, int b) {
        a = Math.abs(a);
        b = Math.abs(b);
        //Propriedade6
        final int maior = Math.max(a, b);
        b = Math.min(a, b);
        a = maior;
        //Propriedade 1
        if (b > 0 && a % b == 0) {
            return b;
        }
        //Propriedade 3
        if (b == 0) {
            return Math.abs(a);
        }
        //Propriedade5
        if (a % b != 0) {
            return 1;
        }
        return -1;
    }
}
